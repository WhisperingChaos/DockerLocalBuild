
### Purpose
Provides an example that implements the makefile framework offered the GitHub [DockerMakefile](https://github.com/WhisperingChaos/DockerMakefile) repository.

This "sample" project creates a minimal, non-functioning, OpenSSH server docker image called _"sshserver"_ that  is then statically included in another image that includes _"mysql"_

### Concepts

+ **Component**:  An object that defines a docker image build context.  It is implemented as a directory whose name reflects the image's name in the local repository.  This directory contains the Dockerfile needed to build a specific docker image and any resources referenced by this Dockerfile included in the resulting image.

  For this project, the directories: _".../sample/sshserver"_ and _".../sample/mysql"_ implement Components.

+ **Image GUID List**:  An object that maintains a list of docker image GUIDs generated when building a specific Component.  The different GUIDs in this list represent various image versions generated due to alterations applied to resources, like a Dockerfile, that comprise a Component's (image's) build context.   A standard text file is used to implement each Image GUID List.  The text file is assigned the same name as the Component (image) with the suffix _".img"_.  The image GUIDs in the file are ordered from the oldest, which appears as the first line in the text file to the most recent GUID that occupies its last line.

  For this project, the files: _".../sample/image/sshserver.img"_ and _".../sample/image/mysql.img"_ implement Image GUID Lists.

+ **Image Catalog**:  An object that encapsulates all Image GUID Lists.  It's implemented as a directory named "image".

  For this project, the directory: _".../sample/image"_ implements an Image Catalog.
 
+ **Root Resource Directory**:  An object, implemented as a directory, that encapsulates all the aforementioned objects.  It also contains the makefile and bash script directory called "scripts".

  For this project, the directory: _".../sample"_ implements a Root Resource Directory.

